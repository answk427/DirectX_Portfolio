#pragma once
#include "MsgProcedure.h"
#include "GameObject.h"

class ComponentDialog : public MsgProcedure
{
public:
	HWND m_hDlg; //dialog	
	HWND m_hwndParent; //main window
public:
	ComponentDialog(HINSTANCE hInstance) : MsgProcedure(hInstance) {}
public:
	// MsgProcedure��(��) ���� ��ӵ�
	virtual bool OpenDialog() override;
	
private:
	virtual void MenuProc(HWND hDlg, WPARAM wParam) override;
	virtual void CharProc(HWND hDlg, WPARAM wParam) override;
	virtual void KeyDownProc(WPARAM wParam) override;
	virtual void MouseMoveProc(WPARAM btnState, LPARAM mousePos) override;
public:
	virtual bool SetObject(GameObject* obj) = 0;
	virtual bool UpdateView() = 0;
	virtual bool OpenDialog(HWND hwnd) = 0;
	
};
