#include "MainWindowDialog.h"

bool MainWindowDialog::OpenDialog()
{
	return false;
}

void MainWindowDialog::MenuProc(HWND hDlg, WPARAM wParam)
{
}

void MainWindowDialog::CharProc(HWND hDlg, WPARAM wParam)
{
}

void MainWindowDialog::KeyDownProc(WPARAM wParam)
{
}

void MainWindowDialog::MouseMoveProc(WPARAM btnState, LPARAM mousePos)
{
}
