#include "ComponentDialog.h"

bool ComponentDialog::OpenDialog()
{
	return false;
}

void ComponentDialog::MenuProc(HWND hDlg, WPARAM wParam)
{
}

void ComponentDialog::CharProc(HWND hDlg, WPARAM wParam)
{
}

void ComponentDialog::KeyDownProc(WPARAM wParam)
{
}

void ComponentDialog::MouseMoveProc(WPARAM btnState, LPARAM mousePos)
{
}
