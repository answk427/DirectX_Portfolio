#pragma once

#pragma region FileTypeDefine

#define FILETYPE_MESH "mesh"

#pragma endregion


#pragma region FolderNameDefine

#define FOLDERNAME_MESH "Meshes"

#pragma endregion






