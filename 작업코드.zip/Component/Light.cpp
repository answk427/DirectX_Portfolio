#include "Light.h"

int Lighting::lightCount[4] = { 0 };


void Lighting::SetDiffuse(const XMFLOAT4& diffuse)
{
	if (compareRGBA(m_dirLight.Diffuse, diffuse))
		return;
	m_dirLight.Diffuse = diffuse;
	m_pointLight.Diffuse = diffuse;
	m_spotLight.Diffuse = diffuse;
}

void Lighting::SetAmbient(const XMFLOAT4& ambient)
{
	if (compareRGBA(m_dirLight.Ambient, ambient))
		return;
	m_dirLight.Ambient = ambient;
	m_pointLight.Ambient = ambient;
	m_spotLight.Ambient = ambient;
}

void Lighting::SetSpecular(const XMFLOAT4& specular)
{
	if (compareRGBA(m_dirLight.Specular, specular))
		return;
	m_dirLight.Specular = specular;
	m_pointLight.Specular = specular;
	m_pointLight.Specular = specular;
}

void Lighting::SetBasic(const XMFLOAT4 & diffuse, const XMFLOAT4 & ambient, const XMFLOAT4 & specular)
{
	SetDiffuse(diffuse);
	SetAmbient(ambient);
	SetSpecular(specular);
}

void Lighting::SetLightType(LightType lightType)
{
	if (m_lightType == lightType)
		return;

	lightCount[m_lightType]--;
	lightCount[lightType]++;
	m_lightType = lightType;
}

void Lighting::SetDirection(const XMFLOAT3 & direction)
{
	if (m_dirLight.Direction.x == direction.x &&
		m_dirLight.Direction.y == direction.y &&
		m_dirLight.Direction.z == direction.z)
		return;

	m_dirLight.Direction = direction;
	m_spotLight.Direction = direction;
}

void Lighting::SetRange(float range)
{
	if (m_pointLight.Range == range)
		return;
	m_pointLight.Range = range;
	m_spotLight.Range = range;
}

void Lighting::SetAtt(const XMFLOAT3& att)
{
	if (m_pointLight.Att.x == att.x &&
		m_pointLight.Att.y == att.y &&
		m_pointLight.Att.z == att.z)
		return;

	m_pointLight.Att = att;
	m_spotLight.Att = att;
}

void Lighting::SetSpot(float spot)
{
	if (m_spotLight.Spot == spot)
		return;
	m_spotLight.Spot = spot;
}

void Lighting::Init()
{
}

void Lighting::FixedUpdate()
{
}

void Lighting::Update()
{
	if (transform == nullptr)
		return;
	//���� ��ġ ������Ʈ
	m_spotLight.Position = transform->m_position;
	m_pointLight.Position = transform->m_position;
}

void Lighting::LateUpdate()
{
}

void Lighting::Enable()
{
	lightCount[m_lightType]++;
}

void Lighting::Disable()
{
	lightCount[m_lightType]--;
}
